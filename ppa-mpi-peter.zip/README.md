# 3-SAT usando AG com OpenMP

## Requisitos
* GCC 9.3.0+
* OpenMP 5.0+

