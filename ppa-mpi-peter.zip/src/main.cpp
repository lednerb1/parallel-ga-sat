/** Trabalho de PPA - K SAT
 * 
 *   Professor
 *       Guilherme Koslovski
 *   Aluno
 *      Peter Brendel
 *
 *   Compilação:
 *     $ make -> Versão final
 *     $ make debug -> Versão pra debug
 * 
 **/

#include <bits/stdc++.h>
#include <unistd.h>
#include <mpi.h>
#include <omp.h>

#include "config.hpp"
#include "clause.hpp"
#include "ga.hpp"

using namespace std::chrono;
using timer = system_clock;

int main(int argc, char* argv[]) {

    int rank, size;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if(argc < 2){
        std::cout << "Usage: ./a.out PathToInputFile" << std::endl;
        exit(1);
    }

    size_t bitsInInt = sizeof(int)*8 - 1;

    std::ifstream is (argv[1], std::fstream::in);

    std::string temp;
    std::string fname(argv[1]);
    int k, literalCount, clauseCount;
    // Read all lines until configuration (cnf) line is reached
    while(is >> temp && temp != "cnf");
    // Read configuration variables
    is >> k >> literalCount >> clauseCount;
    printf("%d-SAT\n%d Literals\n%d Clauses\n", k, literalCount, clauseCount);
    if (is.peek() == '\n') {
        is.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    Config * config = new Config(fname, literalCount, clauseCount, k, size, rank);
    byte * literals = (byte*) malloc(sizeof(byte) * literalCount); //new byte[literalCount]; // C++ malloc
    Clause * clauses = (Clause*) malloc(sizeof(Clause)*clauseCount); // C malloc 
    int clauseIndex = 0;
    
    // Itera sobre o arquivo de entrada pra ler cada clausula
    while (is.peek() != '%') {
        int literal, index=0;
        std::shared_ptr<byte[]> literalPointers(new byte[k]);
        std::shared_ptr<byte[]> literalOperator(new byte[k]);
        
        while (is.peek() != '\n') {
            is >> literal;
            if (!literal) break;
            #ifdef DEBUG
            // std::cout << literal << std::endl;
            #endif

            literalPointers[index] = (byte)abs(literal)-1;
            // Salvamos o endereco daquele liteal
            literalOperator[index] = ((unsigned)literal) >> bitsInInt;
            /* Salvamos `Shift intBits pra direita` no mesmo indice.
             *      Se literal < 0, resulta em 1. Estamos negando o literal (a XOR 1 = ~a)
             *      Caso contrario, resulta em 0. Nao vamos negar o literal (a XOR 0 =  a)
             */
            index++;
        };
        #ifdef DEBUG
        std::cout << "clauseIndex:" << clauseIndex << std::endl;
        #endif
        clauses[clauseIndex] = Clause(literalPointers, literalOperator, k);
        clauseIndex++;
        is.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    std::cout << "hm" << std::endl;
    std::ofstream os (config->getFileName() + "-" + std::string(std::getenv("OMP_NUM_THREADS")) + "t.dat", std::fstream::app);
    GeneticAlgorithm ga = GeneticAlgorithm(config, clauses, literals, 100, 10000, 0.8, 0.05);

    using namespace std::chrono_literals;
    auto begin = high_resolution_clock::now();        
    auto out = ga.evolve();
    os << duration_cast<milliseconds> (high_resolution_clock::now() - begin).count() << '\n';

    std::cout << (float)out.first / config->getClauses() << std::endl;
    std::cout << "---" << std::endl;
    
    MPI_Finalize();
    return 0;
}
