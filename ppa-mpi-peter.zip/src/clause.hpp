#pragma once

#include <bits/stdc++.h>

typedef unsigned char byte;
typedef struct clause {
private:
    byte m_size;
    std::shared_ptr<byte[]> m_literals;
    std::shared_ptr<byte[]> m_operator;
public:
    clause();
    clause(std::shared_ptr<byte[]>& literals, std::shared_ptr<byte[]>& operators, byte size) {
        m_literals = literals;
        m_operator = operators;
        m_size = size;
    }
    byte evaluate(std::vector<byte>& instance) {
        for(int i=0; i < m_size; i++) {
            if (instance[m_literals[i]] ^ m_operator[i]) return 1;
        }
        return 0;
    }
} Clause;